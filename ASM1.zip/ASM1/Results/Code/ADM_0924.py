# -*- coding: utf-8 -*-
import mysql.connector
import pandas as pd
from time import time

def mainQ1():
    t0 = time()
    config = {
        'user': 'root',   
        'password': '2333',  
        'host': '127.0.0.1',  
        'database': 'adm',  
        'raise_on_warnings': True
    }

    try:
        cnx = mysql.connector.connect(**config)
        cursor = cnx.cursor()
        query = """
        SELECT 
            l_returnflag,
            l_linestatus,
            SUM(l_quantity) AS sum_qty,
            SUM(l_extendedprice) AS sum_base_price,
            SUM(l_extendedprice * (1 - l_discount)) AS sum_disc_price,
            SUM(l_extendedprice * (1 - l_discount) * (1 + l_tax)) AS sum_charge,
            AVG(l_quantity) AS avg_qty,
            FORMAT(AVG(l_extendedprice),2) AS avg_price,
            FORMAT(AVG(l_discount), 2) AS avg_disc,
            COUNT(*) AS count_order
        FROM 
            lineitem
        WHERE 
            l_shipdate <= DATE '1998-12-01' - INTERVAL 90 DAY
        GROUP BY 
            l_returnflag, l_linestatus
        ORDER BY 
            l_returnflag, l_linestatus;
        """
        cursor.execute(query)
        df1 = pd.DataFrame(cursor.fetchall(), columns=[desc[0] for desc in cursor.description])
        print(df1)

    except mysql.connector.Error as e:
        print(f"Error: {e}")

    finally:
        cursor.close()
        cnx.close()
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df1
    
mainQ1()

def mainQ6():
    t0 = time()
    config = {
        'user': 'root', 
        'password': '2333',
        'host': '127.0.0.1', 
        'database': 'adm', 
        'raise_on_warnings': True
    }

    try:
        cnx = mysql.connector.connect(**config)
        cursor = cnx.cursor()

        query = """
        select sum(l_extendedprice * l_discount) as revenue
from lineitem
where l_shipdate >= date '1994-01-01' and l_shipdate < date '1994-01-01' + interval '1' year
and l_discount between 0.06 - 0.01 and 0.06 + 0.01
and l_quantity < 24

        """
        cursor.execute(query)
        df2 = pd.DataFrame(cursor.fetchall(), columns=[desc[0] for desc in cursor.description])
        print(df2)

    except mysql.connector.Error as e:
        print(f"Error: {e}")

    finally:
        cursor.close()
        cnx.close()
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df2

def validate_results(query,output_df,result_df):
    validation_passed = output_df.equals(result_df)
    print("Validation_passed:{} for {}".format(validation_passed, query))

    

    
def mainQ1_SF3():
    t0 = time()
    config = {
        'user': 'root',   
        'password': '2333',  
        'host': '127.0.0.1',  
        'database': 'adm', 
        'raise_on_warnings': True
    }

    try:
        cnx = mysql.connector.connect(**config)
        cursor = cnx.cursor()

        query = """
        SELECT 
            l_returnflag,
            l_linestatus,
            SUM(l_quantity) AS sum_qty,
            SUM(l_extendedprice) AS sum_base_price,
            SUM(l_extendedprice * (1 - l_discount)) AS sum_disc_price,
            SUM(l_extendedprice * (1 - l_discount) * (1 + l_tax)) AS sum_charge,
            AVG(l_quantity) AS avg_qty,
            FORMAT(AVG(l_extendedprice),2) AS avg_price,
            FORMAT(AVG(l_discount), 2) AS avg_disc,
            COUNT(*) AS count_order
        FROM 
            lineitem2
        WHERE 
            l_shipdate <= DATE '1998-12-01' - INTERVAL 90 DAY
        GROUP BY 
            l_returnflag, l_linestatus
        ORDER BY 
            l_returnflag, l_linestatus;
        """

        cursor.execute(query)
        df3 = pd.DataFrame(cursor.fetchall(), columns=[desc[0] for desc in cursor.description])
        print(df3)

    except mysql.connector.Error as e:
        print(f"Error: {e}")

    finally:
        cursor.close()
        cnx.close()
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df3

def mainQ6_SF3():
    t0 = time()
    config = {
        'user': 'root', 
        'password': '2333',
        'host': '127.0.0.1', 
        'database': 'adm', 
        'raise_on_warnings': True
    }

    try:
        cnx = mysql.connector.connect(**config)
        cursor = cnx.cursor()

        query = """
        select sum(l_extendedprice * l_discount) as revenue
from lineitem2
where l_shipdate >= date '1994-01-01' and l_shipdate < date '1994-01-01' + interval '1' year
and l_discount between 0.06 - 0.01 and 0.06 + 0.01
and l_quantity < 24

        """
        cursor.execute(query)
        df4 = pd.DataFrame(cursor.fetchall(), columns=[desc[0] for desc in cursor.description])
        print(df4)

    except mysql.connector.Error as e:
        print(f"Error: {e}")

    finally:
        cursor.close()
        cnx.close()
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df4


'''SF-10'''
def mainQ1_SF10():
    t0 = time()
    config = {
        'user': 'root',   
        'password': '2333',  
        'host': '127.0.0.1',  
        'database': 'adm',  
        'raise_on_warnings': True
    }

    try:
        cnx = mysql.connector.connect(**config)
        cursor = cnx.cursor()

        query = """
        SELECT 
            l_returnflag,
            l_linestatus,
            SUM(l_quantity) AS sum_qty,
            SUM(l_extendedprice) AS sum_base_price,
            SUM(l_extendedprice * (1 - l_discount)) AS sum_disc_price,
            SUM(l_extendedprice * (1 - l_discount) * (1 + l_tax)) AS sum_charge,
            AVG(l_quantity) AS avg_qty,
            FORMAT(AVG(l_extendedprice),2) AS avg_price,
            FORMAT(AVG(l_discount), 2) AS avg_disc,
            COUNT(*) AS count_order
        FROM 
            lineitem3
        WHERE 
            l_shipdate <= DATE '1998-12-01' - INTERVAL 90 DAY
        GROUP BY 
            l_returnflag, l_linestatus
        ORDER BY 
            l_returnflag, l_linestatus;
        """

        cursor.execute(query)
        df5 = pd.DataFrame(cursor.fetchall(), columns=[desc[0] for desc in cursor.description])
        print(df5)
    except mysql.connector.Error as e:
        print(f"Error: {e}")
    finally:
        cursor.close()
        cnx.close()
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df5

def mainQ6_SF10():
    t0 = time()
    config = {
        'user': 'root', 
        'password': '2333',
        'host': '127.0.0.1', 
        'database': 'adm', 
        'raise_on_warnings': True
    }

    try:
        cnx = mysql.connector.connect(**config)
        cursor = cnx.cursor()

        query = """
        select sum(l_extendedprice * l_discount) as revenue
from lineitem3
where l_shipdate >= date '1994-01-01' and l_shipdate < date '1994-01-01' + interval '1' year
and l_discount between 0.06 - 0.01 and 0.06 + 0.01
and l_quantity < 24

        """
        cursor.execute(query)
        df6 = pd.DataFrame(cursor.fetchall(), columns=[desc[0] for desc in cursor.description])
        print(df6)

    except mysql.connector.Error as e:
        print(f"Error: {e}")

    finally:
        cursor.close()
        cnx.close()
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df6


if __name__ == "__main__":
    query_time_sumQ1SF1 = 0
    query_time_sumQ6SF1 = 0
    query_time_sumQ1SF10 = 0
    query_time_sumQ1SF3 = 0
    query_time_sumQ6SF3 = 0
    query_time_sumQ6SF10 = 0
    repetition = 10
    for i in range(repetition):
        query_time, df1 = mainQ1()
        query_time_sumQ1SF1 += query_time
        query_time, df2 = mainQ6()
        query_time_sumQ6SF1 += query_time
        query_time, df3 = mainQ1_SF3()
        query_time_sumQ1SF3 += query_time
        query_time, df4 = mainQ6_SF3()
        query_time_sumQ6SF3 += query_time
        query_time, df5 = mainQ1_SF10()
        query_time_sumQ1SF10 += query_time
        query_time, df6 = mainQ6_SF10()
        query_time_sumQ6SF10 += query_time
    print("average query time Q1 for SF1:{}".format(query_time_sumQ1SF1/repetition ))
    print("average query time Q6 for SF1:{}".format(query_time_sumQ6SF1/repetition ))
    print("average query time Q1 for SF3:{}".format(query_time_sumQ1SF3/repetition ))
    print("average query time Q6 for SF3:{}".format(query_time_sumQ6SF3/repetition ))
    print("average query time Q1 for SF10:{}".format(query_time_sumQ1SF10/repetition ))
    print("average query time Q6 for SF10:{}".format(query_time_sumQ6SF10/repetition ))
    
df1.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\MySQL\MySQL_SF1_Q1")
df2.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\MySQL\MySQL_SF1_Q6")
df3.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\MySQL\MySQL_SF3_Q1")
df4.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\MySQL\MySQL_SF3_Q6")
df5.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\MySQL\MySQL_SF10_Q1")
df6.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\MySQL\MySQL_SF10_Q6")
    
    
#True result verification
pd.set_option('display.float_format', '{:,.2f}'.format)
query_time, df1 = mainQ1()
query_time, df2 = mainQ6()
query_time, df3 = mainQ1_SF3()
query_time, df4 = mainQ6_SF3()

def convert_query(dataframe):
    dataframe['sum_disc_price'] = dataframe['sum_disc_price'].astype(float)
    dataframe['sum_disc_price'] = dataframe['sum_disc_price'].apply(lambda x: '{:,.2f}'.format(x))
    dataframe['sum_base_price'] = dataframe['sum_base_price'].apply(lambda x: '{:,.2f}'.format(x))
    dataframe['sum_charge'] = dataframe['sum_charge'].apply(lambda x: '{:,.2f}'.format(x))
    dataframe['avg_qty'] = dataframe['avg_qty'].apply(lambda x: '{:,.2f}'.format(x))
    dataframe['sum_qty'] = dataframe['sum_qty'].astype(int)
    dataframe['avg_price'] = dataframe['avg_price'].str.replace(',', '').astype(float)
    dataframe['avg_disc'] = dataframe['avg_disc'].astype(float)

def convert_answer(expected_df):
    expected_df['sum_qty'] = expected_df['sum_qty'].astype(int)
    expected_df['sum_base_price'] = expected_df['sum_base_price'].apply(lambda x: '{:,.2f}'.format(x))
    expected_df['sum_disc_price'] = expected_df['sum_disc_price'].apply(lambda x: '{:,.2f}'.format(x))
    expected_df['sum_charge'] = expected_df['sum_charge'].apply(lambda x: '{:,.2f}'.format(x))
    expected_df['avg_price'] = expected_df['avg_price'].astype(float)
    expected_df['avg_qty'] = expected_df['avg_qty'].apply(lambda x: '{:,.2f}'.format(x)).astype(object)
    expected_df['avg_disc'] = expected_df['avg_disc'].astype(float)
    
convert_query(df1)
convert_query(df3)

expected_df = pd.read_csv(r'E:\TPC-H_V3.0.1++\dbgen\answers\q1.out', sep='|', skiprows=1, header=None)
expected_df.columns = [
    'l_returnflag', 'l_linestatus', 'sum_qty', 'sum_base_price', 
    'sum_disc_price', 'sum_charge', 'avg_qty', 'avg_price', 
    'avg_disc', 'count_order'
]


expected_df3 = pd.read_csv(r'E:\TPC-H_V3.0.1++\dbgen\SF-3\results\q01.res.csv',skiprows=1, header=None)
expected_df3.columns = [
    'l_returnflag', 'l_linestatus', 'sum_qty', 'sum_base_price', 
    'sum_disc_price', 'sum_charge', 'avg_qty', 'avg_price', 
    'avg_disc', 'count_order'
]

convert_answer(expected_df)
convert_answer(expected_df3)


expected_df2 = pd.read_csv(r'E:\TPC-H_V3.0.1++\dbgen\answers\q6.out', skiprows=1,header=None)
expected_df2.columns = ['revenue']
expected_df2['revenue'] = expected_df2['revenue'].apply(lambda x: '{:,.2f}'.format(x))
df2['revenue'] = df2['revenue'].apply(lambda x: '{:,.2f}'.format(x))

expected_df4 = pd.read_csv(r'E:\TPC-H_V3.0.1++\dbgen\SF-3\results\q06.res.csv',skiprows=1, header=None)
expected_df4.columns = ['revenue']
expected_df4['revenue'] = expected_df4['revenue'].apply(lambda x: '{:,.2f}'.format(x))
df4['revenue'] = df4['revenue'].apply(lambda x: '{:,.2f}'.format(x))


#verification
validate_results('Q1_SF-1',df1,expected_df)
validate_results('Q6_SF-1',df2,expected_df2)
validate_results('Q1_SF-3',df3,expected_df3)
validate_results('Q6_SF-3',df4,expected_df4)


columns_to_compare = [
    'l_returnflag', 'l_linestatus', 'sum_qty', 'sum_base_price',  
    'sum_disc_price', 'sum_charge', 'avg_qty', 'avg_price', 
    'avg_disc', 'count_order'
]

comparison_results = {}

for column in columns_to_compare:
    comparison_results[column] = df2[column].equals(expected_df2[column])
list(comparison_results.items())





#Draw
import matplotlib.pyplot as plt
data = {
    'Scale Factor': ['Q1-SF1', 'Q1-SF3', 'Q1-SF10'],
    'PostgreSQL': [2.3, 9.2, 20.7],
    'MySQL': [20.2, 60.4, 182.2],
    'MonetDB': [0.3, 0.5, 0.8]
}
data2 = {
    'Scale Factor': ['Q6-SF1', 'Q6-SF3', 'Q6-SF10'],
    'PostgreSQL': [0.4, 0.6, 0.5],
    'MySQL': [4.7, 4.6, 5.0],
    'MonetDB': [0.2, 0.2, 0.3]
}

df = pd.DataFrame(data)

# Plotting the data
plt.figure(figsize=(10, 6))
plt.plot(df['Scale Factor'], df['PostgreSQL'], label='PostgreSQL', marker='o')
plt.plot(df['Scale Factor'], df['MySQL'], label='MySQL', marker='o')
plt.plot(df['Scale Factor'], df['MonetDB'], label='MonetDB', marker='o')

# Adding titles and labels
plt.title('Q1 Execution Time Comparison Across DBMSs', fontsize=25)
#plt.title('Q6 Execution Time Comparison Across DBMSs', fontsize=25)
plt.xlabel('Scale Factor', fontsize=18)
plt.ylabel('Execution Time (seconds)', fontsize=18)
plt.legend()

# Show the plot
plt.grid(True)
plt.show()























