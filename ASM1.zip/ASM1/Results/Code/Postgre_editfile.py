#edit the .tbl file in order to let it readable by postgre
with open(r'E:\\TPC-H_V3.0.1++\\dbgen\\SF-1\\data\\lineitem.tbl', 'r') as file:
    lines = file.readlines()

cleaned_lines = [line.rstrip('|\n') + '\n' for line in lines]
with open('E:\\TPC-H_V3.0.1++\\dbgen\\SF-1\\data\\lineitem_r.tbl', 'w') as file:
    file.writelines(cleaned_lines)

with open(r'E:\\TPC-H_V3.0.1++\\dbgen\\SF-3\\data\\lineitem.tbl', 'r') as file:
    lines = file.readlines()

cleaned_lines = [line.rstrip('|\n') + '\n' for line in lines]
with open('E:\\TPC-H_V3.0.1++\\dbgen\\SF-3\\data\\lineitem_r.tbl', 'w') as file:
    file.writelines(cleaned_lines)
    
#Extract the first 45,000,000 rows of sf-10
with open('E:\\TPC-H_V3.0.1++\\SF-10\\data\\lineitem.tbl', 'r') as infile, open('E:\\TPC-H_V3.0.1++\\SF-10\\data\\output.tbl', 'w') as outfile:
    for i, line in enumerate(infile):
        if i < 45000000:
            outfile.write(line)
        else:
            break

with open('E:\\TPC-H_V3.0.1++\\SF-10\\data\\output.tbl', 'r') as file:
    lines = file.readlines()

cleaned_lines = [line.rstrip('|\n') + '\n' for line in lines]
with open('E:\\TPC-H_V3.0.1++\\SF-10\\data\\output_r.tbl', 'w') as file:
    file.writelines(cleaned_lines)


    
import psycopg2
import pandas as pd
from time import time

#SF1
def mainQ1():
    t0 = time()
    db_params = {
    'host': 'localhost',
    'port': '5432',
    'dbname': 'postgres',
    'user': 'postgres',
    'password': '2333'
    }


    connection = psycopg2.connect(**db_params)
    cursor = connection.cursor()

    query = """
        SELECT 
            l_returnflag,
            l_linestatus,
            SUM(l_quantity) AS sum_qty,
            SUM(l_extendedprice) AS sum_base_price,
            SUM(l_extendedprice * (1 - l_discount)) AS sum_disc_price,
            SUM(l_extendedprice * (1 - l_discount) * (1 + l_tax)) AS sum_charge,
            AVG(l_quantity) AS avg_qty,
            TO_CHAR(AVG(l_extendedprice), 'FM999999999.00') AS avg_price,
            TO_CHAR(AVG(l_discount), 'FM999999999.00') AS avg_disc,
            COUNT(*) AS count_order
        FROM 
            lineitem
        WHERE 
            l_shipdate <= DATE '1998-12-01' - INTERVAL '90 DAY'
        GROUP BY 
            l_returnflag, l_linestatus
        ORDER BY 
            l_returnflag, l_linestatus;
    """

    cursor.execute(query)
    results = cursor.fetchall()

    columns = [
        'l_returnflag', 'l_linestatus', 'sum_qty', 'sum_base_price', 
        'sum_disc_price', 'sum_charge', 'avg_qty', 'avg_price', 
        'avg_disc', 'count_order'
    ]
    df1 = pd.DataFrame(results, columns=columns)
    print(df1)
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df1

mainQ1()


def mainQ6():
    t0 = time()
    db_params = {
    'host': 'localhost',
    'port': '5432',
    'dbname': 'postgres',
    'user': 'postgres',
    'password': '2333'
    }

    connection = psycopg2.connect(**db_params)
    cursor = connection.cursor()
    query = """
        select sum(l_extendedprice * l_discount) as revenue
from lineitem
where l_shipdate >= date '1994-01-01' and l_shipdate < date '1994-01-01' + interval '1' year
and l_discount between 0.06 - 0.01 and 0.06 + 0.01
and l_quantity < 24
        """

    cursor.execute(query)
    results = cursor.fetchall()

    columns = [
        'revenue'
    ]
    df2 = pd.DataFrame(results, columns=columns)
    print(df2)
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df2

mainQ6()




#SF3
def mainQ1_SF3():
    t0 = time()
    db_params = {
    'host': 'localhost',
    'port': '5432',
    'dbname': 'postgres',
    'user': 'postgres',
    'password': '2333'
    }

    connection = psycopg2.connect(**db_params)
    cursor = connection.cursor()

    query = """
        SELECT 
            l_returnflag,
            l_linestatus,
            SUM(l_quantity) AS sum_qty,
            SUM(l_extendedprice) AS sum_base_price,
            SUM(l_extendedprice * (1 - l_discount)) AS sum_disc_price,
            SUM(l_extendedprice * (1 - l_discount) * (1 + l_tax)) AS sum_charge,
            AVG(l_quantity) AS avg_qty,
            TO_CHAR(AVG(l_extendedprice), 'FM999999999.00') AS avg_price,
            TO_CHAR(AVG(l_discount), 'FM999999999.00') AS avg_disc,
            COUNT(*) AS count_order
        FROM 
            lineitem2
        WHERE 
            l_shipdate <= DATE '1998-12-01' - INTERVAL '90 DAY'
        GROUP BY 
            l_returnflag, l_linestatus
        ORDER BY 
            l_returnflag, l_linestatus;
    """

    cursor.execute(query)
    results = cursor.fetchall()

    columns = [
        'l_returnflag', 'l_linestatus', 'sum_qty', 'sum_base_price', 
        'sum_disc_price', 'sum_charge', 'avg_qty', 'avg_price', 
        'avg_disc', 'count_order'
    ]
    df3 = pd.DataFrame(results, columns=columns)
    print(df3)
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df3

mainQ1_SF3()


def mainQ6_SF3():
    t0 = time()
    db_params = {
    'host': 'localhost',
    'port': '5432',
    'dbname': 'postgres',
    'user': 'postgres',
    'password': '2333'
    }

    connection = psycopg2.connect(**db_params)
    cursor = connection.cursor()

    query = """
        select sum(l_extendedprice * l_discount) as revenue
from lineitem2
where l_shipdate >= date '1994-01-01' and l_shipdate < date '1994-01-01' + interval '1' year
and l_discount between 0.06 - 0.01 and 0.06 + 0.01
and l_quantity < 24
        """

    cursor.execute(query)
    results = cursor.fetchall()

    columns = ['revenue']
    df4 = pd.DataFrame(results, columns=columns)
    print(df4)
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df4

mainQ6_SF3()




#SF10
def mainQ1_SF10():
    t0 = time()
    db_params = {
    'host': 'localhost',
    'port': '5432',
    'dbname': 'postgres',
    'user': 'postgres',
    'password': '2333'
    }

    connection = psycopg2.connect(**db_params)
    cursor = connection.cursor()

    query = """
        SELECT 
            l_returnflag,
            l_linestatus,
            SUM(l_quantity) AS sum_qty,
            SUM(l_extendedprice) AS sum_base_price,
            SUM(l_extendedprice * (1 - l_discount)) AS sum_disc_price,
            SUM(l_extendedprice * (1 - l_discount) * (1 + l_tax)) AS sum_charge,
            AVG(l_quantity) AS avg_qty,
            TO_CHAR(AVG(l_extendedprice), 'FM999999999.00') AS avg_price,
            TO_CHAR(AVG(l_discount), 'FM999999999.00') AS avg_disc,
            COUNT(*) AS count_order
        FROM 
            lineitem3
        WHERE 
            l_shipdate <= DATE '1998-12-01' - INTERVAL '90 DAY'
        GROUP BY 
            l_returnflag, l_linestatus
        ORDER BY 
            l_returnflag, l_linestatus;
    """

    cursor.execute(query)
    results = cursor.fetchall()

    columns = [
        'l_returnflag', 'l_linestatus', 'sum_qty', 'sum_base_price', 
        'sum_disc_price', 'sum_charge', 'avg_qty', 'avg_price', 
        'avg_disc', 'count_order'
    ]
    df5 = pd.DataFrame(results, columns=columns)
    print(df5)
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df5

mainQ1_SF10()


def mainQ6_SF10():
    t0 = time()
    db_params = {
    'host': 'localhost',
    'port': '5432',
    'dbname': 'postgres',
    'user': 'postgres',
    'password': '2333'
    }

    connection = psycopg2.connect(**db_params)
    cursor = connection.cursor()

    query = """
        select sum(l_extendedprice * l_discount) as revenue
from lineitem3
where l_shipdate >= date '1994-01-01' and l_shipdate < date '1994-01-01' + interval '1' year
and l_discount between 0.06 - 0.01 and 0.06 + 0.01
and l_quantity < 24
        """

    cursor.execute(query)
    results = cursor.fetchall()

    columns = ['revenue']
    df6 = pd.DataFrame(results, columns=columns)
    print(df6)
    t1 = time()
    query_time = t1-t0
    print("query time:{}".format(query_time))
    return query_time, df6

mainQ6_SF10()




if __name__ == "__main__":
    query_time_sumQ1SF1 = 0
    query_time_sumQ6SF1 = 0
    query_time_sumQ1SF10 = 0
    query_time_sumQ1SF3 = 0
    query_time_sumQ6SF3 = 0
    query_time_sumQ6SF10 = 0
    repetition = 4
    for i in range(repetition):
        print(i)
        query_time, df1 = mainQ1()
        query_time_sumQ1SF1 += query_time
        query_time, df2 = mainQ6()
        query_time_sumQ6SF1 += query_time
        query_time, df3 = mainQ1_SF3()
        query_time_sumQ1SF3 += query_time
        query_time, df4 = mainQ6_SF3()
        query_time_sumQ6SF3 += query_time
        query_time, df5 = mainQ1_SF10()
        query_time_sumQ1SF10 += query_time
        query_time, df6 = mainQ6_SF10() #35
        query_time_sumQ6SF10 += query_time
    print("average query time Q1 for SF1:{}".format(query_time_sumQ1SF1/repetition ))
    print("average query time Q6 for SF1:{}".format(query_time_sumQ6SF1/repetition ))
    print("average query time Q1 for SF3:{}".format(query_time_sumQ1SF3/repetition ))
    print("average query time Q6 for SF3:{}".format(query_time_sumQ6SF3/repetition ))
    print("average query time Q1 for SF10:{}".format(query_time_sumQ1SF10/repetition ))
    print("average query time Q6 for SF10:{}".format(query_time_sumQ6SF10/repetition ))
    
df1.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\Postgre\Postgre_SF1_Q1")
df2.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\Postgre\Postgre_SF1_Q6")
df3.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\Postgre\Postgre_SF3_Q1")
df4.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\Postgre\Postgre_SF3_Q6")
df5.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\Postgre\Postgre_SF10_Q1")
df6.to_csv("E:\Semester 3\ZA\ADM\ASM1\Results\Postgre\Postgre_SF10_Q6")