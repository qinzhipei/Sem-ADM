# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 20:29:48 2024

@author: admin
"""

import sys
import struct
import random
import time

num_entries = 50000000
file_path = r"E:\Semester 3\ZA\ADM\ASM4\random_data.bin"

def heap(arr, n, i):
    largest = i
    left = 2 * i + 1 
    right = 2 * i + 2 

    if left < n and arr[left] > arr[largest]:
        largest = left

    if right < n and arr[right] > arr[largest]:
        largest = right

    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]  
        heap(arr, n, largest)

def heap_sort(arr):
    n = len(arr)

    for i in range(n // 2 - 1, -1, -1):
        heap(arr, n, i)

    for i in range(n - 1, 0, -1):
        arr[i], arr[0] = arr[0], arr[i] 
        heap(arr, i, 0) 

# 读取文件中的4字节整数并返回数组
def read_integers_from_file(file_path):
    data = []
    with open(file_path, "rb") as f:
        while True:
            bytes_data = f.read(4)
            if not bytes_data:
                break
            # 解包 4 字节为无符号整数
            number = struct.unpack('I', bytes_data)[0]
            data.append(number)
    return data



def main():
    print(sys.argv)
    if len(sys.argv) == 1:
        sys.argv = ["heap_sort.py", "20000000", r"E:\Semester 3\ZA\ADM\ASM4\random_data.bin"] 
    
    if len(sys.argv) != 3:
        sys.stderr.write("Usage: python3 heap_sort.py <number_of_values> <file_path>\n")
        sys.exit(1)
    
    # 获取命令行参数
    n = int(sys.argv[1]) 
    file_path = sys.argv[2] 

    with open(file_path, "rb") as f: 
            data = []
            for _ in range(n):
                bytes_data = f.read(4) 
                
                if not bytes_data:
                    break
                number = struct.unpack('I', bytes_data)[0]
                data.append(number)

    t0 = time.time()
    heap_sort(data)
    t1 = time.time()
        
    print("Processing time:{}".format(t1-t0))
    time.sleep(3)
        
    for number in data:
        print(number)
        

if __name__ == "__main__":
    main()
