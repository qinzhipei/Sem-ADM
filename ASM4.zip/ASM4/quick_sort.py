# -*- coding: utf-8 -*-

import sys
import struct
import random
import time

#Generate Random 4-byte integer
num_entries = 50000000
file_path = r"E:\Semester 3\ZA\ADM\ASM4\random_data.bin"


'''with open(file_path, 'wb') as f:
    for _ in range(num_entries):
        random_int = random.randint(0, 2147483647)
        f.write(struct.pack('I', random_int))'''


def quick_sort(arr, low, high):
    if low < high:
        pivot = arr[high]
        i = low - 1 
        
        for j in range(low, high):
            if arr[j] <= pivot:
                i += 1
                arr[i], arr[j] = arr[j], arr[i]
        
        arr[i + 1], arr[high] = arr[high], arr[i + 1]
        
        quick_sort(arr, low, i)
        quick_sort(arr, i + 2, high)

def main():
    print(sys.argv)
    if len(sys.argv) == 1:
        sys.argv = ["quick_sort.py", "10000000", r"E:\Semester 3\ZA\ADM\ASM4\random_data.bin"]  # 修改为需要的模拟参数
    
    if len(sys.argv) != 3:
        sys.stderr.write("Usage: python3 quick_sort.py <number_of_values> <file_path>\n")
        sys.exit(1)
    
    n = int(sys.argv[1])
    file_path = sys.argv[2]
    with open(file_path, "rb") as f:
        data = []
        for _ in range(n):
            bytes_data = f.read(4)
            
            if not bytes_data:
                break
            number = struct.unpack('I', bytes_data)[0]
            data.append(number)
    t0 = time.time()
    quick_sort(data, 0, len(data) - 1)
    t1 = time.time()
    print("Processing time:{}".format(t1-t0))
    time.sleep(3)
    for number in data:
        print(number)

        
if __name__ == "__main__":
    main()